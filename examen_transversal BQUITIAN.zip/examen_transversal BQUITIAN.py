import os
import random
import csv
import statistics
import funcioness as f
os.system('cls')


while True:
    opc=f.menu('menu principal',['Asignar_sueldos','Clasificar_sueldos','Ver_estadisticas','Reporte_sueldos'])
    if opc==1:
        continue
    elif opc==2:
       continue
    elif opc==3:
        continue
    elif opc==4:
        continue
    else:
        print('')